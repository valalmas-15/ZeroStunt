package com.example.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

class MainActivity : AppCompatActivity() {
    private lateinit var interpreter: Interpreter

    // Normalization parameters (mean and std) from the scaler.pkl
    private val meanValues = floatArrayOf(
        14.90277319f,  // for Gender (or the first feature, as required)
        2.76429515f,   // for Age
        49.09078904f,  // for Birth Weight
        7.61678772f,   // for Birth Length
        69.04057445f   // for Body Weight
    )

    private val stdValues = floatArrayOf(
        8.60481693f,   // for Gender (or the first feature, as required)
        0.2959524f,    // for Age
        0.43457117f,   // for Birth Weight
        1.769163f,     // for Birth Length
        9.49217264f    // for Body Weight
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Load the TFLite model
        interpreter = Interpreter(loadModelFile())

        val buttonPredict: Button = findViewById(R.id.buttonPredict)
        buttonPredict.setOnClickListener {
            predictStunting()
        }
    }

    private fun loadModelFile(): ByteBuffer {
        val assetFileDescriptor = assets.openFd("model.tflite")
        val fileInputStream = assetFileDescriptor.createInputStream()
        val fileChannel = fileInputStream.channel
        val startOffset = assetFileDescriptor.startOffset
        val declaredLength = assetFileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    private fun predictStunting() {
        val editTextGender: EditText = findViewById(R.id.editTextGender)
        val editTextAge: EditText = findViewById(R.id.editTextAge)
        val editTextBirthWeight: EditText = findViewById(R.id.editTextBirthWeight)
        val editTextBirthLength: EditText = findViewById(R.id.editTextBirthLength)
        val editTextBodyWeight: EditText = findViewById(R.id.editTextBodyWeight)
        val editTextBodyLength: EditText = findViewById(R.id.editTextBodyLength)
        val textViewResult: TextView = findViewById(R.id.textViewResult)

        val gender = editTextGender.text.toString().toFloat()
        val age = editTextAge.text.toString().toFloat()
        val birthWeight = editTextBirthWeight.text.toString().toFloat()
        val birthLength = editTextBirthLength.text.toString().toFloat()
        val bodyWeight = editTextBodyWeight.text.toString().toFloat()
        val bodyLength = editTextBodyLength.text.toString().toFloat()

        // Normalize the inputs using mean and std
        val normalizedAge = normalize(age, meanValues[0], stdValues[0])
        val normalizedBirthWeight = normalize(birthWeight, meanValues[1], stdValues[1])
        val normalizedBirthLength = normalize(birthLength, meanValues[2], stdValues[2])
        val normalizedBodyWeight = normalize(bodyWeight, meanValues[3], stdValues[3])
        val normalizedBodyLength = normalize(bodyLength, meanValues[4], stdValues[4])

        // Create input buffer (6 features for the model)
        val inputBuffer = ByteBuffer.allocateDirect(6 * 4).order(ByteOrder.nativeOrder())
        inputBuffer.putFloat(gender)  // Gender (0 for female, 1 for male)
        inputBuffer.putFloat(normalizedAge)
        inputBuffer.putFloat(normalizedBirthWeight)
        inputBuffer.putFloat(normalizedBirthLength)
        inputBuffer.putFloat(normalizedBodyWeight)
        inputBuffer.putFloat(normalizedBodyLength)
        inputBuffer.rewind()

        // Create output buffer (1 output for prediction)
        val outputBuffer = ByteBuffer.allocateDirect(1 * 4).order(ByteOrder.nativeOrder())

        // Run inference
        interpreter.run(inputBuffer, outputBuffer)

        // Read the prediction result
        outputBuffer.rewind()
        val prediction = outputBuffer.float

        // Interpret the result based on threshold
        val result = if (prediction > 0.7) "Stunting" else "Tidak Stunting"
        textViewResult.text = "Prediksi Stunting: $result $prediction $gender $normalizedAge $normalizedBirthWeight $normalizedBirthLength $normalizedBodyWeight $normalizedBodyLength"
    }

    // Normalize using mean and std (like StandardScaler)
    private fun normalize(value: Float, mean: Float, std: Float): Float {
        return (value - mean) / std
    }

    override fun onDestroy() {
        super.onDestroy()
        interpreter.close()
    }
}
